import 'package:flutter/material.dart';

import 'add_heart_rate.dart';

//this code is developed by Ayush

class HeartRateMain extends StatefulWidget {
  const HeartRateMain({super.key});

  @override
  State<HeartRateMain> createState() => _HeartRateMainState();
}

class _HeartRateMainState extends State<HeartRateMain> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(100.0), // here the desired height
          child: AppBar(
              leading: InkWell(
                  borderRadius: BorderRadius.circular(90),
                  onTap: () {},
                  child: Icon(Icons.arrow_back_ios, color: Colors.white)),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.vertical(
                  bottom: Radius.circular(30),
                ),
              ),
              title: Text(
                'Heart Rate',
                style: TextStyle(color: Colors.white),
              ),
              centerTitle: true,
              backgroundColor: Color.fromRGBO(112, 43, 146, 1)),
        ),
        body: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 189,
                  height: 141,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    color: Color.fromRGBO(251, 244, 255, 1),
                  ),
                  margin: EdgeInsets.only(top: 20, left: 5),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            margin: EdgeInsets.only(top: 15, left: 15),
                            //color: Colors.yellow,
                            child: Text(
                              'Average BPM',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 18,
                              ),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Container(
                            margin: EdgeInsets.only(top: 15, left: 15),
                            //color: Colors.green,
                            child: Text(
                              '70',
                              style: TextStyle(
                                fontWeight: FontWeight.w300,
                                fontSize: 40,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Container(
                  width: 189,
                  height: 141,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    color: Color.fromRGBO(245, 245, 245, 1),
                  ),
                  margin: EdgeInsets.only(top: 20, left: 20),
                  child: Column(
                    //mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            margin: EdgeInsets.only(top: 15, left: 15),
                            //color: Colors.yellow,
                            child: Text(
                              'Standard Limits',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 18,
                              ),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          Container(
                            margin: EdgeInsets.only(top: 15, left: 15),
                            //color: Colors.green,
                            child: Row(
                              children: [
                                Text(
                                  'Pulse Rate : ',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w300,
                                    fontSize: 16,
                                  ),
                                ),
                                Text(
                                  '60 - 100',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 16,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 25,
            ),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 20),
              width: double.infinity,
              height: 50,
              decoration: BoxDecoration(
                color: Color.fromRGBO(234, 234, 234, 1),
                borderRadius: BorderRadius.all(Radius.circular(100)),
              ),
              child: TabBar(
                //isScrollable: true,
                tabAlignment: TabAlignment.fill,
                indicatorColor: Colors.transparent,
                dividerHeight: 0,
                padding: EdgeInsets.symmetric(horizontal: 20),
                unselectedLabelColor: Color.fromRGBO(74, 74, 74, 1),
                labelColor: Color.fromRGBO(0, 0, 0, 1),
                indicatorPadding: EdgeInsets.symmetric(vertical: 1),
                indicator: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(100)),
                tabs: [
                  Center(child: Tab(text: 'Weekly')),
                  Center(child: Tab(text: 'Monthly')),
                ],
              ),
            ),
            Expanded(
              child: TabBarView(
                children: [
                  //content for weekly
                  Padding(
                    padding: const EdgeInsets.symmetric(
                         horizontal: 20),
                    child: Container(
                      //margin: EdgeInsets.only(top: 15),
                      width: 388,
                      height: 20,
                      //color: Colors.yellow,
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                child: Row(
                                  children: [
                                    Image.asset(
                                      'assets/icon/Ellipse 91.png',
                                      width: 8,
                                      height: 8,
                                    ),
                                    Text(
                                      'BPM',
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                child: Text(
                                  'view graph data',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w300,
                                    color: Color.fromRGBO(112, 43, 146, 1),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Image.asset('assets/images/Group 1000002378.png'),
                          Container(
                            //color: Colors.yellow,
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      'Today, Aug 19',
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 5,),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      child: Row(
                                        children: [
                                          Text(
                                            'Pulse Rate: ',
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w300,
                                            ),
                                          ),
                                          Text(
                                            '72 BPM',
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      child: Text(
                                        '03:30 PM',
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w300,
                                          color: Color.fromRGBO(
                                              112, 43, 146, 1),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Divider(height: 5,),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      child: Row(
                                        children: [
                                          Text(
                                            'Pulse Rate: ',
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w300,
                                            ),
                                          ),
                                          Text(
                                            '71 BPM',
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w400,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      child: Text(
                                        '01:15 PM',
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w300,
                                          color: Color.fromRGBO(
                                              112, 43, 146, 1),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Divider(height: 5,),
                                SizedBox(height: 20,),
                                ElevatedButton(
                                  onPressed: () {
                                    showModalBottomSheet<void>(
                                      context: context,
                                      builder: (context) => AddHeartRate(),
                                    );
                                  },
                                  style: ElevatedButton.styleFrom(
                                    foregroundColor: Color.fromRGBO(112, 43, 146, 1),
                                    backgroundColor: Color.fromRGBO(251, 244, 255, 1),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(
                                          100), // Adjust the radius as needed
                                    ),
                                    minimumSize: Size(350, 54),
                                  ),
                                  child: Text('ADD NEW'),
                                ),
                              ],
                            ),
                          ),
                        ],

                      ),

                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
