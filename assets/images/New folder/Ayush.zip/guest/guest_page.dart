import 'package:demo/Auth/Register.dart';
import 'package:demo/guest/guest_register.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

//this code is developed by Ayush

class GuestPage extends StatefulWidget {
  const GuestPage({Key? key}) : super(key: key);

  @override
  State<GuestPage> createState() => _GuestPageState();
}

class _GuestPageState extends State<GuestPage> {
  List ico = [
    'assets/images/podcast.png',
    'assets/images/recipe-book.png',
    'assets/images/inspiration.png',
  ];

  List ico_la_up = [
    'Podcasts',
    'Recipes Ideas',
    'Daily Inspiration',
  ];

  List access_icon = [
    'assets/images/voice-control.png',
    'assets/images/call-center-agent.png',
    'assets/images/note.png',
    'assets/images/note-book.png',
    'assets/images/audio-book.png'
  ];

  List access_text = [
    'Audio Programmes',
    'Exercise & Pilates',
    'Healthy Meal Plan',
    'Weekly Workbook & Assist',
    'Audio Books & Video'
  ];

  List Matrics = [
    'assets/images/heart-attack.png',
    'assets/images/heart_rate.png',
    'assets/images/Weight_Machine.png',
    'assets/images/fruits.png'
  ];

  List bg_img = [
    'assets/images/line1.png',
    'assets/images/line2.png',
    'assets/images/line3.png',
    'assets/images/line4.png'
  ];

  List ros = ['Heart Rate', 'Blood Pressure', 'Weight Logging', 'Food Logging'];
  List ros2 = ['96 bpm', '120/80 mm Hg', '150.2 lbs (68.2 kg)', '350 gm'];

  List btn_ico = ['assets/icon/phone.png', 'assets/icon/assessment.png'];

  List btn_text = ['Request Callback', 'Book Assessment'];

  int _curre_ = 0;
  List<Widget> body = const [
    ////// comment for Navigation ///////////////////////////////////////////////////////////////////
    Icon(Icons.home),
    Icon(Icons.menu),
    Icon(Icons.person),
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'this is under con..',
      home: Scaffold(
        body: Column(
          children: [
            Stack(
              children: [
                Container(
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 25),
                  width: double.infinity,
                  height: 130,
                  decoration: BoxDecoration(
                    color: Color.fromRGBO(112, 43, 146, 1),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(30),
                      bottomRight: Radius.circular(30),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 60, left: 20),
                  child: Container(
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Text(
                              'Hello 👋',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w300,
                                  fontSize: 18,
                                  fontFamily: 'Mulish'),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Text(
                              'Guest12',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 24,
                                  fontWeight: FontWeight.w700,
                                  fontFamily: 'Mulish'),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 60, left: 330),
                  child: Container(
                    width: 54,
                    height: 54,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: Colors.white,
                    ),
                    child: Image.asset(
                      'assets/images/user 1.png',
                    ),
                  ),
                )
              ],
            ),
            // const SizedBox(height: 8),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        children: [
                          GridView.builder(
                            gridDelegate:
                                SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              crossAxisSpacing: 7.0,
                              mainAxisSpacing: 7.0,
                              mainAxisExtent: 70,
                            ),
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: 3,
                            itemBuilder: (context, index) {
                              return InkWell(
                                borderRadius: BorderRadius.circular(10),
                                onTap: () {},
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(20)),
                                  ),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: Image.asset(
                                          ico[index],
                                          height: 34,
                                          width: 34,
                                        ),
                                      ),
                                      SizedBox(
                                        width: 4,
                                      ),
                                      Expanded(
                                        child: Text(
                                          ico_la_up[index],
                                          style: TextStyle(
                                            color: Colors.black,
                                            fontFamily: 'Mulish',
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        width: 4,
                                      ),
                                      Icon(
                                        Icons.arrow_forward_ios,
                                        size: 20,
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 25),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Row(
                          children: [
                            Text(
                              'Sign in to access these features',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                                color: Colors.black,
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Icon(
                              Icons.lock,
                              color: Colors.grey,
                              size: 20,
                            ),
                          ],
                        ),
                      ),
                    ),
                    ListView.builder(
                      shrinkWrap: true,
                      itemCount: access_icon.length,
                      itemBuilder: (context, index) {
                        return Padding(
                          padding: const EdgeInsets.only(left: 20, right: 20),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(10),
                            onTap: () {
                              showModalBottomSheet<void>(
                                context: context,
                                builder: (context) => GuestRegister(),
                              );
                            },
                            child: Padding(
                              padding: const EdgeInsets.all(0.01),
                              child: Container(
                                width: 388,
                                height: 60,
                                padding: EdgeInsets.symmetric(horizontal: 10),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Container(
                                      child: Container(
                                        child: Row(
                                          children: [
                                            Image.asset(
                                              access_icon[index],
                                              height: 34,
                                              width: 34,
                                            ),
                                            SizedBox(
                                              width: 20,
                                            ),
                                            Text(
                                              access_text[index],
                                              style: TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w500,
                                                color:
                                                    Color.fromRGBO(74, 74, 74, 1),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Icon(
                                      Icons.arrow_forward_ios_outlined,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 25),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        child: Row(
                          children: [
                            Text(
                              'Metrics',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.w700,
                                color: Colors.black,
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Icon(
                              Icons.lock,
                              color: Colors.grey,
                              size: 20,
                            ),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: GridView.builder(
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            crossAxisSpacing: 10.0,
                            mainAxisSpacing: 7.0,
                          ),
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: 4,
                          itemBuilder: (context, index) {
                            return InkWell(
                              borderRadius: BorderRadius.circular(20),
                              onTap: () {},
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color:
                                            Color.fromRGBO(238, 238, 238, 1)),
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(20))),
                                child: Stack(
                                  alignment: Alignment.topRight,
                                  children: [
                                    ClipRRect(
                                        borderRadius: BorderRadius.only(
                                            topRight: Radius.circular(20)),
                                        child: Image.asset(bg_img[index])),
                                    Column(
                                      children: [
                                        Row(
                                          children: [
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 15, top: 15),
                                              child: Image.asset(
                                                Matrics[index],
                                                height: 44,
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(
                                          height: 30,
                                        ),
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(left: 15),
                                          child: Column(
                                            children: [
                                              Row(
                                                children: [
                                                  Text(
                                                    ros[index],
                                                    style: TextStyle(
                                                        color: Color.fromRGBO(
                                                            74, 74, 74, 1),
                                                        fontWeight:
                                                            FontWeight.w400,
                                                        fontFamily: 'Mulish',
                                                        fontSize: 16),
                                                  ),
                                                ],
                                              ),
                                              Row(
                                                children: [
                                                  Expanded(
                                                    child: Text(
                                                      ros2[index],
                                                      style: TextStyle(
                                                          color: Color.fromRGBO(
                                                              0, 0, 0, 1),
                                                          fontWeight:
                                                              FontWeight.w700,
                                                          fontFamily: 'Mulish',
                                                          fontSize: 18),
                                                    ),
                                                  )
                                                ],
                                              )
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          }),
                    ),
                  ],
                ),
              ),
            ),
            GridView.builder(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 7.0,
                mainAxisSpacing: 7.0,
                mainAxisExtent: 70,
              ),
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: 2,
              itemBuilder: (context, index) {
                return Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 2),
                      child: ElevatedButton(
                        style: ButtonStyle(
                            shape: MaterialStateProperty.all<
                                    RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    side: BorderSide(
                                        color: Color.fromRGBO(
                                            112, 43, 146, 0.8))))),
                        onPressed: null,
                        child: Row(
                          children: [
                            Image.asset(btn_ico[index], width: 24, height: 24),
                            SizedBox(
                              width: 10,
                            ),
                            Text(
                              btn_text[index],
                              style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13,
                                  color: Colors.black),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                );
              },
            ),
          ],
        ),
        bottomNavigationBar: Container(
          child: BottomNavigationBar(
            backgroundColor: Color.fromRGBO(112, 43, 146, 1),
            selectedItemColor: Colors.white,
            showUnselectedLabels: false,
            selectedIconTheme: IconThemeData(size: 25),
            unselectedItemColor: Colors.grey,
            currentIndex: _curre_,
            onTap: (int newIndex) {
              setState(() {
                _curre_ = newIndex;
              });
            },
            items: [
              BottomNavigationBarItem(
                label: 'Home',
                icon: ImageIcon(AssetImage('assets/images/home.png')),
              ),
              BottomNavigationBarItem(
                  label: 'Shop',
                  icon: ImageIcon(AssetImage('assets/images/shop.png'))),
              BottomNavigationBarItem(
                label: 'Message',
                icon: ImageIcon(AssetImage('assets/images/comments.png')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// Container(
//   color: Colors.white,
//   child: SingleChildScrollView(
//     child: Column(
//       children: [
//         Container(
//           padding: EdgeInsets.symmetric(vertical: 10, horizontal: 25),
//           width: double.infinity,
//           height: 160,
//           decoration: BoxDecoration(
//             color: Color.fromRGBO(112, 43, 146, 1),
//             borderRadius: BorderRadius.only(
//               bottomLeft: Radius.circular(30),
//               bottomRight: Radius.circular(30),
//             ),
//           ),
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.end,
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                 children: [
//                   Text(
//                     "Hello 👋",
//                     style: TextStyle(
//                       color: Colors.white,
//                       fontSize: 14,
//                     ),
//                   ),
//                   Container(
//                     width: 64,
//                     height: 64,
//                     decoration: BoxDecoration(
//                       color: Colors.white,
//                       borderRadius: BorderRadius.circular(10),
//                     ),
//                     child: Center(
//                       child: CircleAvatar(
//                         radius: 20,
//                         backgroundColor: Colors.white,
//                         // Add your user logo here
//                         backgroundImage: AssetImage(
//                             'assets/images/user.png'),
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//               Text(
//                 "Guest 12",
//                 style: TextStyle(
//                   color: Colors.white,
//                   fontSize: 19,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ],
//           ),
//         ),
//         const SizedBox(height: 16),
//         Padding(
//           padding: const EdgeInsets.all(5.0),
//           child: GridView.builder(
//             gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//               crossAxisCount: 2,
//               crossAxisSpacing: 5.0,
//               mainAxisSpacing: 10.0,
//               childAspectRatio: 3.5,
//               mainAxisExtent: 90,
//             ),
//             shrinkWrap: true,
//             physics: NeverScrollableScrollPhysics(),
//             itemCount: 3,
//             itemBuilder: (context, index) {
//               List<GridItem> gridItems = [
//                 GridItem(
//                   iconPath: 'assets/images/podcast.png',
//                   label: 'Podcasts',
//                   labelColor: Colors.black,
//                   showArrow: true,
//                   iconSize: 25,
//                   fontSize: 13,
//                   onTap: () {},
//                   backgroundColor: Colors.grey[200],
//                 ),
//                 GridItem(
//                   iconPath: 'assets/images/inspiration.png',
//                   label: 'Daily Inspiration',
//                   labelColor: Colors.black,
//                   showArrow: true,
//                   iconSize: 25,
//                   fontSize: 11,
//                   onTap: () {},
//                   backgroundColor: Colors.grey[200],
//                 ),
//                 GridItem(
//                   iconPath: 'assets/images/recipe-book.png',
//                   label: 'Recipes Ideas',
//                   labelColor: Colors.black,
//                   showArrow: true,
//                   iconSize: 25,
//                   fontSize: 13,
//                   onTap: () {},
//                   backgroundColor: Colors.grey[200],
//                 ),
//               ];
//               if (index < gridItems.length) {
//                 return gridItems[index];
//               }
//               return SizedBox.shrink();
//             },
//           ),
//         ),
//         const SizedBox(height: 16),
//         Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 20.0),
//           child: Row(
//             children: [
//               SizedBox(width: 8),
//               Text(
//                 'Sign in to access these features',
//                 style: TextStyle(
//                   fontSize: 14,
//                   fontWeight: FontWeight.bold,
//                   color: Colors.black,
//                 ),
//               ),
//               Icon(
//                 Icons.lock,
//                 color: Colors.grey,
//                 size: 20,
//               ),
//             ],
//           ),
//         ),
//         const SizedBox(height: 10),
//         ListView.builder(
//           shrinkWrap: true,
//           physics: NeverScrollableScrollPhysics(),
//           itemCount: 5,
//           itemBuilder: (context, index) {
//             List<ListItem> listItems = [
//               ListItem(
//                 iconPath: 'assets/images/voice-control.png',
//                 label: 'Audio Programmes',
//                 onTap: () {},
//                 backgroundColor: Colors.white,
//               ),
//               ListItem(
//                 iconPath:
//                     'assets/images/call-center-agent.png',
//                 label: 'Exercise & Pilates',
//                 onTap: () {},
//                 backgroundColor: Colors.white,
//               ),
//               ListItem(
//                 iconPath: 'assets/images/note.png',
//                 label: 'Healthy Meal Plan',
//                 onTap: () {},
//                 backgroundColor: Colors.white,
//               ),
//               ListItem(
//                 iconPath: 'assets/images/note-book.png',
//                 label: 'Weekly Workbook & Assist',
//                 onTap: () {},
//                 backgroundColor: Colors.white,
//               ),
//               ListItem(
//                 iconPath: 'assets/images/audio-book.png',
//                 label: 'Audio Books & Video',
//                 onTap: () {},
//                 backgroundColor: Colors.white,
//               ),
//             ];
//             if (index < listItems.length) {
//               return listItems[index];
//             }
//             return SizedBox.shrink();
//           },
//         ),
//         const SizedBox(height: 10),
//         Padding(
//           padding: const EdgeInsets.symmetric(horizontal: 20.0),
//           child: Row(
//             children: [
//               SizedBox(width: 8),
//               Text(
//                 'Metrics',
//                 style: TextStyle(
//                   fontSize: 16,
//                   fontWeight: FontWeight.bold,
//                   color: Colors.black,
//                 ),
//               ),
//               Icon(
//                 Icons.lock,
//                 color: Colors.grey,
//                 size: 20,
//               ),
//             ],
//           ),
//         ),
//         SizedBox(height: 10),
//         Padding(
//           padding: const EdgeInsets.all(7.0),
//           child: GridView.builder(
//             gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
//               crossAxisCount: 2,
//               crossAxisSpacing: 10.0,
//               mainAxisSpacing: 20.0,
//               mainAxisExtent: 80,
//             ),
//             shrinkWrap: true,
//             physics: NeverScrollableScrollPhysics(),
//             itemCount: 2,
//             itemBuilder: (context, index) {
//               List<GridItem> buttonItems = [
//                 GridItem(
//                   iconPath: 'assets/images/phone.png',
//                   label: 'Request Callback',
//                   labelColor: Colors.black,
//                   showArrow: false,
//                   iconSize: 20,
//                   fontSize: 10,
//                   onTap: () {},
//                   borderColor: Color.fromRGBO(112, 43, 146, 1),
//                   backgroundColor: Colors.grey[200],
//                 ),
//                 GridItem(
//                   iconPath: 'assets/images/assessment.png',
//                   label: 'Book Assessment',
//                   labelColor: Colors.black,
//                   showArrow: false,
//                   iconSize: 20,
//                   fontSize: 10,
//                   onTap: () {},
//                   borderColor: Color.fromRGBO(112, 43, 146, 1),
//                   backgroundColor: Colors.grey[200],
//                 ),
//               ];
//               if (index < buttonItems.length) {
//                 return buttonItems[index];
//               }
//               return SizedBox.shrink();
//             },
//           ),
//         ),
//       ],
//     ),
//   ),
// ),
// bottomNavigationBar: BottomNavigationBar(
//   backgroundColor: Color.fromRGBO(112, 43, 146, 1),
//   selectedItemColor: Colors.white,
//   showUnselectedLabels: false,
//   selectedIconTheme: IconThemeData(size: 30),
//   unselectedItemColor: Colors.grey,
//   currentIndex: _curre,
//   onTap: (int newIndex) {
//     setState(() {
//       _curre = newIndex;
//     });
//   },
//   items: [
//     BottomNavigationBarItem(
//       label: 'Home',
//       icon: MouseRegion(
//         cursor: SystemMouseCursors.click,
//         onEnter: (event) => showTooltip(context, 'Home'),
//         onExit: (event) => hideTooltip(),
//         child: ImageIcon(
//           AssetImage('assets/images/home.png'),
//         ),
//       ),
//     ),
//     BottomNavigationBarItem(
//       label: 'Supplement',
//       icon: MouseRegion(
//         cursor: SystemMouseCursors.click,
//         onEnter: (event) => showTooltip(context, 'Supplement'),
//         onExit: (event) => hideTooltip(),
//         child: ImageIcon(
//           AssetImage('assets/images/shop.png'),
//         ),
//       ),
//     ),
//     BottomNavigationBarItem(
//       label: 'Comments',
//       icon: MouseRegion(
//         cursor: SystemMouseCursors.click,
//         onEnter: (event) => showTooltip(context, 'Comments'),
//         onExit: (event) => hideTooltip(),
//         child: ImageIcon(
//           AssetImage('assets/images/comments.png'),
//         ),
//       ),
//     ),
//   ],
// ),

// class GridItem extends StatelessWidget {
//   final String iconPath;
//   final String label;
//   final Color labelColor;
//   final bool showArrow;
//   final double iconSize;
//   final double fontSize;
//   final Color? borderColor;
//   final VoidCallback? onTap;
//   final Color? backgroundColor;
//
//   const GridItem({
//     required this.iconPath,
//     required this.label,
//     required this.labelColor,
//     required this.showArrow,
//     required this.iconSize,
//     required this.fontSize,
//     this.borderColor,
//     this.onTap,
//     this.backgroundColor,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: onTap,
//       child: Container(
//         decoration: BoxDecoration(
//           borderRadius: BorderRadius.circular(10.0),
//           color: backgroundColor ?? Colors.grey[200],
//           border: borderColor != null ? Border.all(color: borderColor!) : null,
//         ),
//         child: Padding(
//           padding: const EdgeInsets.all(8.0),
//           child: Row(
//             mainAxisAlignment: MainAxisAlignment.spaceBetween,
//             children: [
//               Row(
//                 children: [
//                   Image.asset(
//                     iconPath,
//                     width: iconSize,
//                     height: iconSize,
//                   ),
//                   SizedBox(width: 8),
//                   Text(
//                     label,
//                     style: TextStyle(
//                       color: labelColor,
//                       fontWeight: FontWeight.bold,
//                       fontSize: fontSize,
//                     ),
//                   ),
//                 ],
//               ),
//               if (showArrow)
//                 IconButton(
//                   icon: Icon(
//                     Icons.arrow_forward_ios,
//                     size: 14,
//                     color: Colors.black,
//                   ),
//                   onPressed: () {},
//                 ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
//
// class ListItem extends StatelessWidget {
//   final String iconPath;
//   final String label;
//   final VoidCallback onTap;
//   final Color? backgroundColor;
//
//   const ListItem({
//     required this.iconPath,
//     required this.label,
//     required this.onTap,
//     this.backgroundColor,
//   });
//
//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
//       child: Container(
//         decoration: BoxDecoration(
//           color: backgroundColor ?? Colors.white,
//           borderRadius: BorderRadius.circular(10.0),
//           boxShadow: [
//             BoxShadow(
//               color: Colors.grey.withOpacity(0.5),
//               spreadRadius: 2,
//               blurRadius: 5,
//               offset: Offset(0, 3),
//             ),
//           ],
//         ),
//         child: ListTile(
//           leading: Image.asset(
//             iconPath,
//             width: 24,
//             height: 24,
//           ),
//           title: Text(
//             label,
//             style: TextStyle(
//               fontWeight: FontWeight.bold,
//               fontSize: 16,
//             ),
//           ),
//           trailing: IconButton(
//             icon: Icon(
//               Icons.arrow_forward_ios,
//               size: 14,
//               color: Colors.black,
//             ),
//             onPressed: () {},
//           ),
//           onTap: onTap,
//         ),
//       ),
//     );
//   }
// }
//
// void showTooltip(BuildContext context, String message) {}
//
// void hideTooltip() {}
