import 'package:demo/blood%20pressure/add_blood_pressure.dart';
import 'package:flutter/material.dart';

class BloodPressureMain extends StatefulWidget {
  const BloodPressureMain({super.key});

  @override
  State<BloodPressureMain> createState() => _GraphBpState();
}

class _GraphBpState extends State<BloodPressureMain> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(100.0), // here the desired height
          child: AppBar(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(
                bottom: Radius.circular(30),
              ),
            ),
            title: Padding(
              padding: const EdgeInsets.only(top: 35),
              child: Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.arrow_back_ios, color: Colors.white),
                    onPressed: () {

                    },
                  ),
                  Expanded(
                    child: Text(
                      'Blood Pressure',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ],
              ),
            ),
            backgroundColor: Color.fromRGBO(112, 43, 146, 1),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 155,
                    height: 141,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      color: Color.fromRGBO(251, 244, 255, 1),
                    ),
                    margin: EdgeInsets.only(top: 20, left: 5),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Row(
                          children: [
                            Container(
                              margin: EdgeInsets.only(top: 15, left: 15),
                              child: Text(
                                'Average BPM',
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 18,
                                ),
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Container(
                              margin: EdgeInsets.only(top: 15, left: 15),
                              child: Text(
                                '70',
                                style: TextStyle(
                                  fontWeight: FontWeight.w300,
                                  fontSize: 40,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  Container(
                    width: 170,
                    height: 141,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      color: Color.fromRGBO(245, 245, 245, 1),
                    ),
                    margin: EdgeInsets.only(top: 20, left: 20),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Container(
                              margin: EdgeInsets.only(top: 15, left: 10),
                              child: Text(
                                'Standard Limits',
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 18,
                                ),
                              ),
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            Container(
                              margin: EdgeInsets.only(top: 15, left: 10),
                              child: Row(
                                children: [
                                  Text(
                                    'Systolic: <120 mmHg\nDiastolic: <80 mmHg\nPulse Rate: 70 bpm',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w400,
                                      color: Color.fromRGBO(145, 145, 145, 1),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 25,
              ),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 20),
                width: double.infinity,
                height: 50,
                decoration: BoxDecoration(
                  color: Color.fromRGBO(234, 234, 234, 1),
                  borderRadius: BorderRadius.all(Radius.circular(100)),
                ),
                child: TabBar(
                  tabAlignment: TabAlignment.fill,
                  indicatorColor: Colors.transparent,
                  dividerHeight: 0,
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  unselectedLabelColor: Color.fromRGBO(74, 74, 74, 1),
                  labelColor: Color.fromRGBO(0, 0, 0, 1),
                  indicatorPadding: EdgeInsets.symmetric(vertical: 1),
                  indicator: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(100),
                  ),
                  tabs: [
                    Center(child: Tab(text: 'Weekly')),
                    Center(child: Tab(text: 'Monthly')),
                  ],
                ),
              ),
              SizedBox(
                height: 25,
              ),
              Container(
                height: 600, // Adjust height as needed
                child: TabBarView(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                child: Row(
                                  children: [
                                    Image.asset(
                                      'assets/images/blue.png',
                                      width: 8,
                                      height: 8,
                                    ),
                                    Text(
                                      ' Systolic  ',
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                    Image.asset(
                                      'assets/images/yellow.png',
                                      width: 8,
                                      height: 8,
                                    ),
                                    Text(
                                      ' Diastolic',
                                      style: TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                child: Text(
                                  'view graph data',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w300,
                                    color: Color.fromRGBO(112, 43, 146, 1),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Image.asset('assets/images/graph.png'),
                          SizedBox(
                            height: 25,
                          ),
                          Expanded(
                            child: ListView(
                              children: [
                                ListTile(
                                  title: Text(
                                    'Today, Aug 19',
                                    style: TextStyle(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                  subtitle: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            'Systolic: 88 mmHg\nDiastolic: 120 mmHg\nPulse Rate: 70 bpm',
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w400,
                                              color: Color.fromRGBO(145, 145, 145, 1),
                                            ),
                                          ),
                                          Text(
                                            '05:30 PM',
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w300,
                                              color: Color.fromRGBO(112, 43, 146, 1),
                                            ),
                                          ),
                                        ],
                                      ),
                                      Divider(height: 5),
                                    ],
                                  ),
                                ),
                                ListTile(
                                  subtitle: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            'Systolic: 100 mmHg\nDiastolic: 100 mmHg\nPulse Rate: 65 bpm',
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w400,
                                              color: Color.fromRGBO(145, 145, 145, 1),
                                            ),
                                          ),
                                          Text(
                                            '12:00 PM',
                                            style: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w300,
                                              color: Color.fromRGBO(145, 145, 145, 1),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 20),
                                ElevatedButton(
                                  onPressed: () {
                                   showModalBottomSheet(context: context, builder:(context)=>AddBloodPressure());
                                  },
                                  style: ElevatedButton.styleFrom(
                                    foregroundColor: Color.fromRGBO(112, 43, 146, 1),
                                    backgroundColor: Color.fromRGBO(251, 244, 255, 1),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(100),
                                    ),
                                    minimumSize: Size(350, 54),
                                  ),
                                  child: Text('ADD NEW'),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Add similar structure for the Monthly tab if needed

                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


